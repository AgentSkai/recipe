package com.example.skai

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.AdapterView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import kotlinx.android.synthetic.main.activity_main.*


class MainActivity : AppCompatActivity() {
    private val title = arrayOf<String>("jollof", "banku","waakye",
    "spaghetti","potato balls","omelet","macaroni","potato croq",

        "jollof rice", "egg rice","sandwich",
        "spaghetti","potato balls","omelet","waakye","macaroni"
        )
    private val image = arrayOf<Int>(
        R.drawable.jollofplus,
        R.drawable.bankuplus,
        R.drawable.waakye,
        R.drawable.spaghetti,
        R.drawable.potatoballs,
        R.drawable.omelet,
        R.drawable.friedcheesemacaroni,
        R.drawable.potatocroq,

        R.drawable.jollofrice,
        R.drawable.sentosaeggrice,
        R.drawable.sandwich,
        R.drawable.spaghetti,
        R.drawable.potatoballs,
        R.drawable.omelet,
        R.drawable.waakye,
        R.drawable.friedcheesemacaroni
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        window.decorView.apply {

            systemUiVisibility = View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                    View.SYSTEM_UI_FLAG_FULLSCREEN
        }
        setContentView(R.layout.activity_main)

        list_view.adapter = ListAdapter(this,image,title)
        list_view.setOnItemClickListener { parent, view, position, id ->

            if (position == 0 ){

                val intent = Intent(this, MainActivity2::class.java)
                startActivity(intent)
            }
            if (position == 1 ){

                val intent = Intent(this, MainActivity2::class.java)
                startActivity(intent)
            }
            if (position == 2 ){

                val intent = Intent(this, MainActivity2::class.java)
                startActivity(intent)            }
            if (position == 3 ){

                val intent = Intent(this, MainActivity2::class.java)
                startActivity(intent)            }
            if (position == 4 ){

                val intent = Intent(this, MainActivity2::class.java)
                startActivity(intent)            }
            if (position == 5 ){

                val intent = Intent(this, MainActivity2::class.java)
                startActivity(intent)            }
            if (position == 6 ){

                val intent = Intent(this, MainActivity2::class.java)
                startActivity(intent)            }
            if (position == 7 ){

                val intent = Intent(this, MainActivity2::class.java)
                startActivity(intent)            }
            if (position == 8 ){

                val intent = Intent(this, MainActivity2::class.java)
                startActivity(intent)            }
        }
    }

}
